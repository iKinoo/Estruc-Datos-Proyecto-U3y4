package com.estructurasdatos.proyecto_U3y4.excepciones;

public class ItemNotFoundException extends RuntimeException {

    public ItemNotFoundException(String msg) {
        super(msg);
    }
}
