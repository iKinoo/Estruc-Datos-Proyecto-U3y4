package com.estructurasdatos.proyecto_U3y4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoUnidad3Y4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
