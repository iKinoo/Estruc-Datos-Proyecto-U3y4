## SetUp

Usar  `.\mvnw spring-boot:run` para iniciar la aplicación

## ToDo
**Ordenamientos**
- [x] Burbuja
- [x] Inserción
- [x] Shellsort
- [x] Quicksort
- [x] Mergesort
- [ ] Mezcla Homogénea

**Búsquedas**

- [x] Árboles binarios de búsqueda
- [x] Árboles AVL
- [ ] Árboles B

